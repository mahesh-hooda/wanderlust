import { ImageWithFallback } from './figma/ImageWithFallback';
import { MapPin, Star, TrendingUp } from 'lucide-react';
import { MapSection } from './MapSection';

export function DiscoverPage() {
  const trendingDestinations = [
    {
      id: '1',
      name: 'Santorini, Greece',
      image: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=600&h=400&fit=crop',
      description: 'White-washed buildings and stunning sunsets',
      posts: 328,
      rating: 4.9,
    },
    {
      id: '2',
      name: 'Kyoto, Japan',
      image: 'https://images.unsplash.com/photo-1679430017765-1dca73d0ca6b?w=600&h=400&fit=crop',
      description: 'Ancient temples and traditional culture',
      posts: 412,
      rating: 5.0,
    },
    {
      id: '3',
      name: 'Iceland Highlands',
      image: 'https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=600&h=400&fit=crop',
      description: 'Glaciers, waterfalls, and northern lights',
      posts: 267,
      rating: 4.8,
    },
  ];

  const featuredGuides = [
    {
      id: '1',
      name: 'Maria Rodriguez',
      image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=200&h=200&fit=crop',
      region: 'South America',
      experience: '8 years',
      verified: true,
      specialty: 'Eco-tourism & Wildlife',
    },
    {
      id: '2',
      name: 'Raj Patel',
      image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop',
      region: 'Southeast Asia',
      experience: '10 years',
      verified: true,
      specialty: 'Cultural Heritage Tours',
    },
    {
      id: '3',
      name: 'Sophie Laurent',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
      region: 'Europe',
      experience: '6 years',
      verified: true,
      specialty: 'Sustainable Travel',
    },
  ];

  const popularExperiences = [
    {
      id: '1',
      title: 'Sunrise Yoga in Bali',
      image: 'https://images.unsplash.com/photo-1588286840104-8957b019727f?w=600&h=400&fit=crop',
      category: 'Wellness',
      price: '$45',
    },
    {
      id: '2',
      title: 'Street Food Tour Bangkok',
      image: 'https://images.unsplash.com/photo-1631692994621-d26f83cf4db8?w=600&h=400&fit=crop',
      category: 'Food & Culture',
      price: '$35',
    },
    {
      id: '3',
      title: 'Alpine Hiking Adventure',
      image: 'https://images.unsplash.com/photo-1686553749776-96e22b5e5827?w=600&h=400&fit=crop',
      category: 'Adventure',
      price: '$80',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Trending Destinations */}
      <section className="mb-12">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="text-teal-600" size={28} />
          <h2 className="text-teal-700">Trending Destinations</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {trendingDestinations.map((destination) => (
            <div
              key={destination.id}
              className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
            >
              <ImageWithFallback
                src={destination.image}
                alt={destination.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-gray-900">{destination.name}</h3>
                  <div className="flex items-center gap-1">
                    <Star className="text-amber-400 fill-amber-400" size={16} />
                    <span className="text-sm text-gray-600">{destination.rating}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-3">{destination.description}</p>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <MapPin size={14} />
                  <span>{destination.posts} posts</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Guides */}
      <section className="mb-12">
        <div className="flex items-center gap-2 mb-6">
          <span className="text-3xl">🧭</span>
          <h2 className="text-teal-700">Featured Tourist Guides</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredGuides.map((guide) => (
            <div
              key={guide.id}
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition-shadow"
            >
              <div className="flex flex-col items-center text-center">
                <div className="relative mb-4">
                  <ImageWithFallback
                    src={guide.image}
                    alt={guide.name}
                    className="w-24 h-24 rounded-full object-cover"
                  />
                  {guide.verified && (
                    <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </div>
                <h3 className="text-gray-900 mb-1">{guide.name}</h3>
                <p className="text-sm text-teal-600 mb-2">{guide.region}</p>
                <p className="text-sm text-gray-600 mb-1">{guide.specialty}</p>
                <p className="text-xs text-gray-500 mb-4">{guide.experience} experience</p>
                <button className="w-full px-4 py-2 bg-gradient-to-r from-teal-500 to-green-500 text-white rounded-full hover:from-teal-600 hover:to-green-600 transition-colors">
                  Contact Guide
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Experiences */}
      <section>
        <div className="flex items-center gap-2 mb-6">
          <span className="text-3xl">✨</span>
          <h2 className="text-teal-700">Popular Experiences</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {popularExperiences.map((experience) => (
            <div
              key={experience.id}
              className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
            >
              <ImageWithFallback
                src={experience.image}
                alt={experience.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs px-3 py-1 bg-teal-100 text-teal-700 rounded-full">
                    {experience.category}
                  </span>
                  <span className="text-green-600">{experience.price}</span>
                </div>
                <h3 className="text-gray-900">{experience.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Map Section */}
      <section className="mt-12">
        <MapSection />
      </section>
    </div>
  );
}
