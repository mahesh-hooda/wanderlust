import { useState } from 'react';
import { ArrowUp, ArrowDown, MessageCircle, Share2, Flag, Star, MapPin, Train, Car, Bike as BicycleIcon, Bus, Plane, Footprints } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Badge } from './ui/badge';

interface PostCardProps {
  id: string;
  author: string;
  authorAvatar: string;
  location: string;
  rating: number;
  safetyRating: number;
  transportMode: 'Car' | 'Bike' | 'Bus' | 'Train' | 'Flight' | 'Walk' | 'Bicycle';
  isEcoFriendly: boolean;
  image: string;
  description: string;
  initialUpvotes: number;
  initialDownvotes: number;
  commentCount: number;
  timeAgo: string;
}

export function PostCard({
  author,
  authorAvatar,
  location,
  rating,
  safetyRating,
  transportMode,
  isEcoFriendly,
  image,
  description,
  initialUpvotes,
  initialDownvotes,
  commentCount,
  timeAgo,
}: PostCardProps) {
  const [upvotes, setUpvotes] = useState(initialUpvotes);
  const [downvotes, setDownvotes] = useState(initialDownvotes);
  const [userVote, setUserVote] = useState<'up' | 'down' | null>(null);
  const [showComments, setShowComments] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [showShare, setShowShare] = useState(false);

  const handleUpvote = () => {
    if (userVote === 'up') {
      setUpvotes(upvotes - 1);
      setUserVote(null);
    } else {
      if (userVote === 'down') setDownvotes(downvotes - 1);
      setUpvotes(upvotes + 1);
      setUserVote('up');
    }
  };

  const handleDownvote = () => {
    if (userVote === 'down') {
      setDownvotes(downvotes - 1);
      setUserVote(null);
    } else {
      if (userVote === 'up') setUpvotes(upvotes - 1);
      setDownvotes(downvotes + 1);
      setUserVote('down');
    }
  };

  const getTransportIcon = () => {
    switch (transportMode) {
      case 'Car': return <Car size={16} />;
      case 'Bike': return <BicycleIcon size={16} />;
      case 'Bus': return <Bus size={16} />;
      case 'Train': return <Train size={16} />;
      case 'Flight': return <Plane size={16} />;
      case 'Walk': return <Footprints size={16} />;
      case 'Bicycle': return <BicycleIcon size={16} />;
    }
  };

  return (
    <>
      <div className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
        {/* Author Info */}
        <div className="p-4 flex items-center gap-3">
          <ImageWithFallback
            src={authorAvatar}
            alt={author}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="text-gray-900">{author}</h3>
              {isEcoFriendly && (
                <Badge className="bg-green-100 text-green-700 border-green-200">
                  🌿 Green Traveler
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 text-gray-500 text-sm mt-0.5">
              <MapPin size={14} />
              <span>{location}</span>
              <span>•</span>
              <span>{timeAgo}</span>
            </div>
          </div>
        </div>

        {/* Image */}
        <ImageWithFallback
          src={image}
          alt={location}
          className="w-full h-80 object-cover"
        />

        {/* Ratings and Transport */}
        <div className="p-4 flex items-center gap-4 border-b border-gray-100">
          <div className="flex items-center gap-1">
            <span className="text-sm text-gray-600">Place:</span>
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={16}
                  className={i < rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}
                />
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <span className="text-sm text-gray-600">Safety:</span>
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={16}
                  className={i < safetyRating ? 'fill-green-500 text-green-500' : 'text-gray-300'}
                />
              ))}
            </div>
          </div>

          <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${
            isEcoFriendly ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
          }`}>
            {getTransportIcon()}
            <span className="text-xs">{transportMode}</span>
          </div>
        </div>

        {/* Description */}
        <div className="p-4">
          <p className="text-gray-700">{description}</p>
        </div>

        {/* Interaction Buttons */}
        <div className="px-4 pb-4 flex items-center gap-4">
          {/* Upvote/Downvote */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleUpvote}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full transition-colors ${
                userVote === 'up'
                  ? 'bg-teal-100 text-teal-700'
                  : 'bg-gray-100 text-gray-600 hover:bg-teal-50'
              }`}
            >
              <ArrowUp size={18} />
              <span>{upvotes}</span>
            </button>
            <button
              onClick={handleDownvote}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full transition-colors ${
                userVote === 'down'
                  ? 'bg-red-100 text-red-700'
                  : 'bg-gray-100 text-gray-600 hover:bg-red-50'
              }`}
            >
              <ArrowDown size={18} />
              <span>{downvotes}</span>
            </button>
          </div>

          {/* Comment */}
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
          >
            <MessageCircle size={18} />
            <span>{commentCount}</span>
          </button>

          {/* Share */}
          <button
            onClick={() => setShowShare(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
          >
            <Share2 size={18} />
          </button>

          {/* Report */}
          <button
            onClick={() => setShowReport(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gray-100 text-gray-600 hover:bg-red-50 hover:text-red-600 transition-colors ml-auto"
          >
            <Flag size={18} />
          </button>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="border-t border-gray-200 p-4 bg-gray-50">
            <div className="space-y-3">
              <div className="flex gap-3">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop"
                  alt="Commenter"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div className="flex-1">
                  <p className="text-sm"><span className="text-gray-900">Sarah M.</span> <span className="text-gray-600">This place looks amazing! How long did you stay?</span></p>
                </div>
              </div>
              <input
                type="text"
                placeholder="Add a comment..."
                className="w-full px-4 py-2 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* Report Dialog */}
      <Dialog open={showReport} onOpenChange={setShowReport}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report Post</DialogTitle>
            <DialogDescription>
              Please select a reason for reporting this post
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <button className="w-full px-4 py-3 text-left rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
              ⚠️ Inappropriate Content
            </button>
            <button className="w-full px-4 py-3 text-left rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
              🚫 Fake Information
            </button>
            <button className="w-full px-4 py-3 text-left rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
              📧 Spam
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={showShare} onOpenChange={setShowShare}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Post</DialogTitle>
            <DialogDescription>
              Share this amazing travel experience
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <button className="w-full px-4 py-3 text-left rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
              🔗 Copy Link
            </button>
            <button className="w-full px-4 py-3 text-left rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
              📱 Share to WhatsApp
            </button>
            <button className="w-full px-4 py-3 text-left rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
              📧 Share via Email
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
