import { useState } from 'react';
import { X, Upload, Star, Award } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';

interface PostUploadFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PostUploadForm({ open, onOpenChange }: PostUploadFormProps) {
  const [placeRating, setPlaceRating] = useState(0);
  const [safetyRating, setSafetyRating] = useState(0);
  const [transportMode, setTransportMode] = useState('');
  const [showEcoBadge, setShowEcoBadge] = useState(false);
  const [ticketUploaded, setTicketUploaded] = useState(false);

  const ecoFriendlyModes = ['Bus', 'Train', 'Bicycle', 'Walk'];

  const handleTransportChange = (mode: string) => {
    setTransportMode(mode);
    if (ecoFriendlyModes.includes(mode) && ticketUploaded) {
      setShowEcoBadge(true);
    }
  };

  const handleTicketUpload = () => {
    setTicketUploaded(true);
    if (ecoFriendlyModes.includes(transportMode)) {
      setShowEcoBadge(true);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Share Your Travel Experience</DialogTitle>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Image Upload */}
            <div>
              <Label>Upload Photo</Label>
              <div className="mt-2 border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-teal-500 transition-colors cursor-pointer">
                <Upload className="mx-auto text-gray-400 mb-2" size={40} />
                <p className="text-gray-600">Click to upload or drag and drop</p>
                <p className="text-sm text-gray-400 mt-1">PNG, JPG up to 10MB</p>
              </div>
            </div>

            {/* Location */}
            <div>
              <Label htmlFor="location">Location</Label>
              <input
                id="location"
                type="text"
                placeholder="Enter destination name"
                className="w-full mt-2 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Share your experience and tips..."
                className="mt-2 min-h-[100px]"
              />
            </div>

            {/* Place Rating */}
            <div>
              <Label>Place Rating ⭐</Label>
              <div className="flex gap-2 mt-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => setPlaceRating(rating)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      size={32}
                      className={rating <= placeRating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Safety Rating */}
            <div>
              <Label>Safety Rating 🛡️</Label>
              <div className="flex gap-2 mt-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    type="button"
                    onClick={() => setSafetyRating(rating)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      size={32}
                      className={rating <= safetyRating ? 'fill-green-500 text-green-500' : 'text-gray-300'}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Mode of Transport */}
            <div>
              <Label>Mode of Transport 🚗</Label>
              <select
                value={transportMode}
                onChange={(e) => handleTransportChange(e.target.value)}
                className="w-full mt-2 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="">Select transport mode</option>
                <option value="Car">🚗 Car</option>
                <option value="Bike">🏍️ Bike</option>
                <option value="Bus">🚌 Bus (Eco-friendly)</option>
                <option value="Train">🚂 Train (Eco-friendly)</option>
                <option value="Flight">✈️ Flight</option>
                <option value="Walk">🚶 Walk (Eco-friendly)</option>
                <option value="Bicycle">🚲 Bicycle (Eco-friendly)</option>
              </select>
            </div>

            {/* Ticket Upload for Eco-friendly Transport */}
            {ecoFriendlyModes.includes(transportMode) && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                <Label>Upload Ticket/Photo (for verification)</Label>
                <div className="mt-2 border-2 border-dashed border-green-300 rounded-lg p-6 text-center hover:border-green-500 transition-colors cursor-pointer">
                  <Upload className="mx-auto text-green-500 mb-2" size={32} />
                  <button
                    type="button"
                    onClick={handleTicketUpload}
                    className="text-green-700 hover:underline"
                  >
                    Click to upload ticket or photo
                  </button>
                  {ticketUploaded && (
                    <p className="text-green-700 mt-2">✓ Ticket uploaded successfully!</p>
                  )}
                </div>
              </div>
            )}

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-teal-500 to-green-500 hover:from-teal-600 hover:to-green-600"
              onClick={() => {
                if (ecoFriendlyModes.includes(transportMode) && ticketUploaded) {
                  setShowEcoBadge(true);
                }
              }}
            >
              Share Experience
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Eco Badge Popup */}
      <Dialog open={showEcoBadge} onOpenChange={setShowEcoBadge}>
        <DialogContent className="max-w-md">
          <div className="text-center py-6">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
              <Award className="text-white" size={40} />
            </div>
            <h2 className="text-green-700 mb-2">🌿 Verified Eco-Friendly Traveler!</h2>
            <p className="text-gray-600 mb-4">
              You earned a Green Traveler badge and 10 Eco Points!
            </p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
              <p className="text-green-800">
                <span className="block mb-2">🎁 Rewards Unlocked:</span>
                <span className="block text-sm">• 10 Eco Points added</span>
                <span className="block text-sm">• 5% discount on eco-tours</span>
                <span className="block text-sm">• Green Traveler badge</span>
              </p>
            </div>
            <Button
              onClick={() => setShowEcoBadge(false)}
              className="bg-gradient-to-r from-green-500 to-green-600"
            >
              Awesome! Continue
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
