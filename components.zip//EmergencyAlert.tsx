import { useState } from 'react';
import { AlertTriangle, Phone, MapPin, Users, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';

export function EmergencyAlert() {
  const [isOpen, setIsOpen] = useState(false);
  const [alertNearby, setAlertNearby] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const handleSendSOS = () => {
    setShowConfirmation(true);
    setTimeout(() => {
      setShowConfirmation(false);
      setIsOpen(false);
    }, 3000);
  };

  // Mock location-based emergency numbers
  const emergencyNumbers = [
    { service: 'Police', number: '100', icon: '🚓' },
    { service: 'Ambulance', number: '102', icon: '🚑' },
    { service: 'Tourist Helpline', number: '1363', icon: '🧳' },
  ];

  return (
    <>
      {/* Emergency Button - Sticky on right edge */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed right-0 top-1/2 -translate-y-1/2 bg-red-500 text-white px-3 py-6 rounded-l-xl shadow-lg hover:bg-red-600 transition-all hover:px-4 z-50 group"
        aria-label="Emergency Alert"
      >
        <div className="flex flex-col items-center gap-2">
          <AlertTriangle size={32} className="animate-pulse" />
          <span className="text-xs [writing-mode:vertical-lr]">SOS</span>
        </div>
      </button>

      {/* Emergency Alert Modal */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle size={28} />
              Emergency Help
            </DialogTitle>
            <DialogDescription>
              Get immediate assistance and alert nearby travelers
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Alert Nearby Toggle */}
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Users className="text-red-600" size={20} />
                  <span className="text-red-900">Alert Nearby Travelers & Guides</span>
                </div>
                <button
                  onClick={() => setAlertNearby(!alertNearby)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    alertNearby ? 'bg-red-500' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${
                      alertNearby ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
              <p className="text-sm text-red-700">
                {alertNearby
                  ? 'Nearby users will be notified of your emergency'
                  : 'Enable to notify nearby community members'}
              </p>
            </div>

            {/* Emergency Numbers */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Phone className="text-gray-600" size={20} />
                <h3 className="text-gray-900">Local Emergency Numbers</h3>
              </div>
              <div className="space-y-2">
                {emergencyNumbers.map((service) => (
                  <a
                    key={service.service}
                    href={`tel:${service.number}`}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors border border-gray-200"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{service.icon}</span>
                      <span className="text-gray-700">{service.service}</span>
                    </div>
                    <span className="text-blue-600">{service.number}</span>
                  </a>
                ))}
              </div>
            </div>

            {/* Current Location */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <MapPin className="text-blue-600 mt-1" size={20} />
                <div>
                  <h3 className="text-blue-900 mb-1">Your Current Location</h3>
                  <p className="text-sm text-blue-700">
                    Ubud, Bali, Indonesia<br />
                    Lat: -8.5069, Long: 115.2625
                  </p>
                </div>
              </div>
            </div>

            {/* SOS Button */}
            <Button
              onClick={handleSendSOS}
              className="w-full bg-red-500 hover:bg-red-600 text-white py-6 text-lg"
            >
              <AlertTriangle className="mr-2" size={24} />
              Send SOS Alert
            </Button>

            <p className="text-xs text-gray-500 text-center">
              Your location and emergency details will be shared with nearby verified guides and community members
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirmation Modal */}
      <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <DialogContent className="max-w-md">
          <div className="text-center py-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="text-green-600" size={40} />
            </div>
            <h2 className="text-green-700 mb-2">Emergency Alert Sent!</h2>
            <p className="text-gray-600 mb-4">
              Nearby travelers and guides have been notified of your emergency.
            </p>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <p className="text-sm text-green-800">
                ✓ 8 nearby travelers notified<br />
                ✓ 3 verified guides alerted<br />
                ✓ Location shared with emergency contacts
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
