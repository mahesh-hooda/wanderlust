import { useState } from 'react';
import { Plus } from 'lucide-react';
import { PostCard } from './PostCard';
import { PostUploadForm } from './PostUploadForm';
import { MapSection } from './MapSection';
import { Button } from './ui/button';

export function HomePage() {
  const [showUploadForm, setShowUploadForm] = useState(false);

  const posts = [
    {
      id: '1',
      author: 'Emma Wilson',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
      location: 'Bali, Indonesia',
      rating: 5,
      safetyRating: 5,
      transportMode: 'Bicycle' as const,
      isEcoFriendly: true,
      image: 'https://images.unsplash.com/photo-1702743599501-a821d0b38b66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcGFyYWRpc2V8ZW58MXx8fHwxNzYyMTkxMzM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Discovered this hidden beach while cycling around Bali. The locals were so welcoming and the water was crystal clear! Perfect spot for sustainable tourism.',
      initialUpvotes: 234,
      initialDownvotes: 5,
      commentCount: 42,
      timeAgo: '2 hours ago',
    },
    {
      id: '2',
      author: 'Marcus Chen',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
      location: 'Swiss Alps, Switzerland',
      rating: 5,
      safetyRating: 4,
      transportMode: 'Train' as const,
      isEcoFriendly: true,
      image: 'https://images.unsplash.com/photo-1686553749776-96e22b5e5827?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3NjIyNDY3MzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Took the scenic train route through the Alps - absolutely breathtaking! The train stations are super accessible and the views are unmatched.',
      initialUpvotes: 189,
      initialDownvotes: 3,
      commentCount: 28,
      timeAgo: '5 hours ago',
    },
    {
      id: '3',
      author: 'Priya Sharma',
      authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop',
      location: 'Kyoto, Japan',
      rating: 5,
      safetyRating: 5,
      transportMode: 'Walk' as const,
      isEcoFriendly: true,
      image: 'https://images.unsplash.com/photo-1679430017765-1dca73d0ca6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmNpZW50JTIwdGVtcGxlJTIwdHJhdmVsfGVufDF8fHx8MTc2MjI0OTQ1OXww&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Walking through the ancient temples of Kyoto at sunrise was magical. The city is so pedestrian-friendly and safe!',
      initialUpvotes: 312,
      initialDownvotes: 7,
      commentCount: 56,
      timeAgo: '1 day ago',
    },
    {
      id: '4',
      author: 'David Miller',
      authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      location: 'Paris, France',
      rating: 4,
      safetyRating: 4,
      transportMode: 'Bus' as const,
      isEcoFriendly: true,
      image: 'https://images.unsplash.com/photo-1667308129069-ad853aa0d8ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxldXJvcGVhbiUyMHN0cmVldCUyMGNhZmV8ZW58MXx8fHwxNzYyMjQ5NDU5fDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Found this charming café in Montmartre. Used the local bus system - affordable and eco-friendly way to explore the city!',
      initialUpvotes: 156,
      initialDownvotes: 4,
      commentCount: 31,
      timeAgo: '2 days ago',
    },
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      {/* Upload Button */}
      <div className="mb-6">
        <Button
          onClick={() => setShowUploadForm(true)}
          className="w-full bg-gradient-to-r from-teal-500 to-green-500 hover:from-teal-600 hover:to-green-600"
        >
          <Plus className="mr-2" size={20} />
          Share Your Travel Experience
        </Button>
      </div>

      {/* Posts Feed */}
      <div className="space-y-6">
        {posts.map((post) => (
          <PostCard key={post.id} {...post} />
        ))}
      </div>

      {/* Map Section */}
      <div className="mt-8">
        <MapSection />
      </div>

      {/* Upload Form Modal */}
      <PostUploadForm open={showUploadForm} onOpenChange={setShowUploadForm} />
    </div>
  );
}
