import { useState } from 'react';
import { MapPin, Users, Building2 } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MapPin {
  id: string;
  type: 'community' | 'destination' | 'business';
  name: string;
  image: string;
  postCount: number;
  lat: number;
  lng: number;
}

export function MapSection() {
  const [selectedPin, setSelectedPin] = useState<MapPin | null>(null);

  const mapPins: MapPin[] = [
    {
      id: '1',
      type: 'destination',
      name: 'Ubud Rice Terraces',
      image: 'https://images.unsplash.com/photo-1702743599501-a821d0b38b66?w=300&h=200&fit=crop',
      postCount: 142,
      lat: 40,
      lng: 30,
    },
    {
      id: '2',
      type: 'community',
      name: 'Bali Eco Travelers',
      image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=300&h=200&fit=crop',
      postCount: 89,
      lat: 60,
      lng: 45,
    },
    {
      id: '3',
      type: 'business',
      name: 'Green Earth Café',
      image: 'https://images.unsplash.com/photo-1631692994621-d26f83cf4db8?w=300&h=200&fit=crop',
      postCount: 56,
      lat: 50,
      lng: 70,
    },
  ];

  const getPinIcon = (type: string) => {
    switch (type) {
      case 'community':
        return <Users size={16} className="text-white" />;
      case 'business':
        return <Building2 size={16} className="text-white" />;
      default:
        return <MapPin size={16} className="text-white" />;
    }
  };

  const getPinColor = (type: string) => {
    switch (type) {
      case 'community':
        return 'bg-purple-500';
      case 'business':
        return 'bg-orange-500';
      default:
        return 'bg-teal-500';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-md overflow-hidden">
      <div className="p-6">
        <h2 className="text-teal-700 mb-4">🗺️ Explore Communities & Nearby Destinations</h2>
        
        {/* Map Container */}
        <div className="relative bg-gradient-to-br from-blue-50 to-green-50 rounded-xl h-96 overflow-hidden border-2 border-gray-200">
          {/* Simplified Map Background */}
          <div className="absolute inset-0 opacity-20">
            <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
              <path d="M0,20 Q25,10 50,20 T100,20" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
              <path d="M0,40 Q25,30 50,40 T100,40" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
              <path d="M0,60 Q25,50 50,60 T100,60" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
              <path d="M20,0 Q10,25 20,50 T20,100" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
              <path d="M40,0 Q30,25 40,50 T40,100" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
              <path d="M60,0 Q50,25 60,50 T60,100" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
              <path d="M80,0 Q70,25 80,50 T80,100" stroke="#94a3b8" strokeWidth="0.5" fill="none" />
            </svg>
          </div>

          {/* Map Pins */}
          {mapPins.map((pin) => (
            <button
              key={pin.id}
              onClick={() => setSelectedPin(pin)}
              className={`absolute ${getPinColor(pin.type)} w-10 h-10 rounded-full shadow-lg hover:scale-110 transition-transform flex items-center justify-center cursor-pointer z-10`}
              style={{
                top: `${pin.lat}%`,
                left: `${pin.lng}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              {getPinIcon(pin.type)}
            </button>
          ))}

          {/* Pin Preview Card */}
          {selectedPin && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white rounded-xl shadow-xl p-4 w-80 z-20">
              <div className="flex gap-3">
                <ImageWithFallback
                  src={selectedPin.image}
                  alt={selectedPin.name}
                  className="w-20 h-20 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h3 className="text-gray-900 mb-1">{selectedPin.name}</h3>
                  <p className="text-sm text-gray-500 mb-2">{selectedPin.postCount} posts</p>
                  <button className="text-sm text-teal-600 hover:text-teal-700">
                    View on Map →
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="mt-4 flex items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-teal-500"></div>
            <span className="text-gray-600">Destinations</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-purple-500"></div>
            <span className="text-gray-600">Communities</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span className="text-gray-600">Local Businesses</span>
          </div>
        </div>
      </div>
    </div>
  );
}
