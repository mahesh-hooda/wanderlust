import { Gift, Sparkles, Award } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function RewardsPage() {
  const rewards = [
    {
      id: '1',
      title: '5% off eco-tours',
      points: 10,
      icon: '🌿',
      description: 'Get 5% discount on all eco-friendly tours',
      image: 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600&h=400&fit=crop',
      category: 'Eco Points',
    },
    {
      id: '2',
      title: 'Free local guide session',
      points: 25,
      icon: '🎒',
      description: '1-hour free consultation with a verified local guide',
      image: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&h=400&fit=crop',
      category: 'Eco Points',
    },
    {
      id: '3',
      title: 'Discount on sustainable stays',
      points: 50,
      icon: '🏕️',
      description: '15% off eco-lodges and sustainable accommodations',
      image: 'https://images.unsplash.com/photo-1754078219069-7565df2033b0?w=600&h=400&fit=crop',
      category: 'Eco Points',
    },
    {
      id: '4',
      title: 'Local cuisine cooking class',
      points: 35,
      icon: '🍜',
      description: 'Free cooking class with local chef',
      image: 'https://images.unsplash.com/photo-1631692994621-d26f83cf4db8?w=600&h=400&fit=crop',
      category: 'Eco Points',
    },
    {
      id: '5',
      title: 'Adventure activity voucher',
      points: 75,
      icon: '⛰️',
      description: '$50 voucher for hiking, diving, or adventure sports',
      image: 'https://images.unsplash.com/photo-1686553749776-96e22b5e5827?w=600&h=400&fit=crop',
      category: 'Eco Points',
    },
    {
      id: '6',
      title: 'Premium travel insurance',
      points: 100,
      icon: '🛡️',
      description: 'One month free premium travel insurance',
      image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&h=400&fit=crop',
      category: 'Eco Points',
    },
  ];

  const userEcoPoints = 42;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-500 to-green-500 rounded-2xl p-8 mb-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Award size={40} />
              <h1>Your Eco Rewards</h1>
            </div>
            <p className="text-teal-50">
              Earn points by traveling sustainably and unlock amazing rewards!
            </p>
          </div>
          <div className="text-center bg-white/20 backdrop-blur-sm rounded-2xl px-8 py-6">
            <div className="flex items-center gap-2 justify-center mb-1">
              <Sparkles size={24} />
              <span className="text-5xl">{userEcoPoints}</span>
            </div>
            <p className="text-sm text-teal-50">Eco Points</p>
          </div>
        </div>
      </div>

      {/* How to Earn Points */}
      <div className="bg-white rounded-2xl shadow-md p-6 mb-8">
        <h2 className="text-teal-700 mb-4">🌟 How to Earn Eco Points</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-start gap-3 p-4 bg-green-50 rounded-xl">
            <span className="text-2xl">🚂</span>
            <div>
              <h3 className="text-gray-900 text-sm mb-1">Use Eco Transport</h3>
              <p className="text-sm text-gray-600">+10 points per verified trip</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-green-50 rounded-xl">
            <span className="text-2xl">📝</span>
            <div>
              <h3 className="text-gray-900 text-sm mb-1">Share Experiences</h3>
              <p className="text-sm text-gray-600">+5 points per post</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-green-50 rounded-xl">
            <span className="text-2xl">🏘️</span>
            <div>
              <h3 className="text-gray-900 text-sm mb-1">Support Local</h3>
              <p className="text-sm text-gray-600">+8 points per review</p>
            </div>
          </div>
        </div>
      </div>

      {/* Rewards Grid */}
      <div>
        <h2 className="text-teal-700 mb-6">🎁 Available Rewards</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rewards.map((reward) => {
            const canRedeem = userEcoPoints >= reward.points;
            
            return (
              <div
                key={reward.id}
                className={`bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-all ${
                  !canRedeem && 'opacity-75'
                }`}
              >
                <div className="relative">
                  <ImageWithFallback
                    src={reward.image}
                    alt={reward.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white rounded-full px-3 py-1.5 shadow-lg">
                    <div className="flex items-center gap-1">
                      <Sparkles size={16} className="text-amber-500" />
                      <span className="text-sm">{reward.points}</span>
                    </div>
                  </div>
                  <div className="absolute top-4 left-4 text-4xl bg-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg">
                    {reward.icon}
                  </div>
                </div>
                
                <div className="p-5">
                  <h3 className="text-gray-900 mb-2">{reward.title}</h3>
                  <p className="text-sm text-gray-600 mb-4">{reward.description}</p>
                  
                  <button
                    disabled={!canRedeem}
                    className={`w-full px-4 py-2 rounded-full transition-colors ${
                      canRedeem
                        ? 'bg-gradient-to-r from-teal-500 to-green-500 text-white hover:from-teal-600 hover:to-green-600'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {canRedeem ? (
                      <>
                        <Gift className="inline mr-2" size={18} />
                        Redeem Now
                      </>
                    ) : (
                      `Need ${reward.points - userEcoPoints} more points`
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
