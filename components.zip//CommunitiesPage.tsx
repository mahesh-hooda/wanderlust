import { useState } from 'react';
import { Users, MapPin, Star, CheckCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

type TabType = 'communities' | 'businesses' | 'guides';

export function CommunitiesPage() {
  const [activeTab, setActiveTab] = useState<TabType>('communities');

  const communities = [
    {
      id: '1',
      name: 'Bali Eco Travelers',
      image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=400&fit=crop',
      members: 1243,
      region: 'Southeast Asia',
      description: 'Community focused on sustainable travel in Bali and nearby islands',
    },
    {
      id: '2',
      name: 'European Budget Backpackers',
      image: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&h=400&fit=crop',
      members: 2891,
      region: 'Europe',
      description: 'Share tips, routes, and experiences for affordable European travel',
    },
    {
      id: '3',
      name: 'Solo Female Travelers',
      image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&h=400&fit=crop',
      members: 3456,
      region: 'Global',
      description: 'Safe travel tips and empowerment for women traveling solo',
    },
  ];

  const businesses = [
    {
      id: '1',
      name: 'Green Earth Café',
      image: 'https://images.unsplash.com/photo-1631692994621-d26f83cf4db8?w=600&h=400&fit=crop',
      category: 'Restaurant',
      location: 'Ubud, Bali',
      rating: 4.8,
      description: 'Organic farm-to-table dining with local ingredients',
    },
    {
      id: '2',
      name: 'Eco Stay Homestay',
      image: 'https://images.unsplash.com/photo-1754078219069-7565df2033b0?w=600&h=400&fit=crop',
      category: 'Accommodation',
      location: 'Chiang Mai, Thailand',
      rating: 4.9,
      description: 'Sustainable bamboo homestay with local family',
    },
    {
      id: '3',
      name: 'Handcraft Market',
      image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=600&h=400&fit=crop',
      category: 'Shopping',
      location: 'Marrakech, Morocco',
      rating: 4.7,
      description: 'Traditional crafts made by local artisans',
    },
  ];

  const guides = [
    {
      id: '1',
      name: 'Carlos Mendez',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
      region: 'Central America',
      experience: '12 years',
      verified: true,
      languages: ['English', 'Spanish', 'Portuguese'],
      specialty: 'Adventure & Wildlife',
      rating: 5.0,
    },
    {
      id: '2',
      name: 'Amara Okafor',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop',
      region: 'West Africa',
      experience: '7 years',
      verified: true,
      languages: ['English', 'French', 'Yoruba'],
      specialty: 'Cultural Heritage',
      rating: 4.9,
    },
    {
      id: '3',
      name: 'Yuki Tanaka',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
      region: 'Japan',
      experience: '9 years',
      verified: true,
      languages: ['English', 'Japanese', 'Mandarin'],
      specialty: 'Traditional Culture & Food',
      rating: 5.0,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Tabs */}
      <div className="flex gap-2 mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveTab('communities')}
          className={`px-6 py-3 rounded-full transition-colors whitespace-nowrap ${
            activeTab === 'communities'
              ? 'bg-gradient-to-r from-teal-500 to-green-500 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          <Users className="inline mr-2" size={20} />
          Local Communities
        </button>
        <button
          onClick={() => setActiveTab('businesses')}
          className={`px-6 py-3 rounded-full transition-colors whitespace-nowrap ${
            activeTab === 'businesses'
              ? 'bg-gradient-to-r from-teal-500 to-green-500 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          🏪 Local Businesses
        </button>
        <button
          onClick={() => setActiveTab('guides')}
          className={`px-6 py-3 rounded-full transition-colors whitespace-nowrap ${
            activeTab === 'guides'
              ? 'bg-gradient-to-r from-teal-500 to-green-500 text-white'
              : 'bg-white text-gray-600 hover:bg-gray-50'
          }`}
        >
          🧭 Tourist Guides
        </button>
      </div>

      {/* Communities Tab */}
      {activeTab === 'communities' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {communities.map((community) => (
            <div
              key={community.id}
              className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-shadow"
            >
              <ImageWithFallback
                src={community.image}
                alt={community.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="text-gray-900 mb-2">{community.name}</h3>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                  <Users size={16} />
                  <span>{community.members.toLocaleString()} members</span>
                  <span>•</span>
                  <MapPin size={16} />
                  <span>{community.region}</span>
                </div>
                <p className="text-gray-600 text-sm mb-4">{community.description}</p>
                <button className="w-full px-4 py-2 bg-teal-500 text-white rounded-full hover:bg-teal-600 transition-colors">
                  Join Community
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Businesses Tab */}
      {activeTab === 'businesses' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {businesses.map((business) => (
            <div
              key={business.id}
              className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition-shadow"
            >
              <ImageWithFallback
                src={business.image}
                alt={business.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-gray-900">{business.name}</h3>
                    <span className="text-xs px-2 py-1 bg-orange-100 text-orange-700 rounded-full">
                      {business.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="text-amber-400 fill-amber-400" size={16} />
                    <span className="text-sm">{business.rating}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-3 mt-2">
                  <MapPin size={16} />
                  <span>{business.location}</span>
                </div>
                <p className="text-gray-600 text-sm mb-4">{business.description}</p>
                <div className="flex gap-2">
                  <button className="flex-1 px-4 py-2 bg-teal-500 text-white rounded-full hover:bg-teal-600 transition-colors">
                    Visit
                  </button>
                  <button className="px-4 py-2 border border-teal-500 text-teal-600 rounded-full hover:bg-teal-50 transition-colors">
                    📍 Map
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Guides Tab */}
      {activeTab === 'guides' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {guides.map((guide) => (
            <div
              key={guide.id}
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition-shadow"
            >
              <div className="flex flex-col items-center text-center">
                <div className="relative mb-4">
                  <ImageWithFallback
                    src={guide.image}
                    alt={guide.name}
                    className="w-28 h-28 rounded-full object-cover"
                  />
                  {guide.verified && (
                    <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                      <CheckCircle className="text-white" size={20} />
                    </div>
                  )}
                </div>
                
                <h3 className="text-gray-900 mb-1">{guide.name}</h3>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="text-amber-400 fill-amber-400" size={16} />
                  <span className="text-sm">{guide.rating}</span>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                  <MapPin size={16} />
                  <span>{guide.region}</span>
                </div>
                
                <p className="text-sm text-teal-600 mb-2">{guide.specialty}</p>
                <p className="text-xs text-gray-500 mb-3">{guide.experience} experience</p>
                
                <div className="flex flex-wrap gap-1 justify-center mb-4">
                  {guide.languages.map((lang) => (
                    <span
                      key={lang}
                      className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full"
                    >
                      {lang}
                    </span>
                  ))}
                </div>
                
                <button className="w-full px-4 py-2 bg-gradient-to-r from-teal-500 to-green-500 text-white rounded-full hover:from-teal-600 hover:to-green-600 transition-colors mb-2">
                  Request Guide
                </button>
                <button className="w-full px-4 py-2 border border-teal-500 text-teal-600 rounded-full hover:bg-teal-50 transition-colors">
                  View Profile
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
