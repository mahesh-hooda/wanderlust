import { Award, CheckCircle, Sparkles, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function ProfilePage() {
  const user = {
    name: 'Alex Thompson',
    username: '@alextravel',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
    ecoPoints: 142,
    verifiedPosts: 28,
    joinedDate: 'March 2024',
  };

  const badges = [
    { id: '1', name: 'Green Traveler', icon: '🌿', earned: true },
    { id: '2', name: 'Community Leader', icon: '👥', earned: true },
    { id: '3', name: 'Explorer', icon: '🗺️', earned: true },
    { id: '4', name: 'Top Contributor', icon: '⭐', earned: false },
    { id: '5', name: 'Eco Warrior', icon: '♻️', earned: true },
    { id: '6', name: 'Cultural Ambassador', icon: '🎭', earned: false },
  ];

  const earnedRewards = [
    {
      id: '1',
      title: '5% off eco-tours',
      icon: '🌿',
      redeemedDate: 'Oct 15, 2024',
    },
    {
      id: '2',
      title: 'Free local guide session',
      icon: '🎒',
      redeemedDate: 'Sep 8, 2024',
    },
    {
      id: '3',
      title: 'Local cuisine cooking class',
      icon: '🍜',
      redeemedDate: 'Aug 22, 2024',
    },
  ];

  const recentPosts = [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1702743599501-a821d0b38b66?w=300&h=300&fit=crop',
      location: 'Bali, Indonesia',
      likes: 234,
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1679430017765-1dca73d0ca6b?w=300&h=300&fit=crop',
      location: 'Kyoto, Japan',
      likes: 312,
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1686553749776-96e22b5e5827?w=300&h=300&fit=crop',
      location: 'Swiss Alps',
      likes: 189,
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Profile Header */}
      <div className="bg-white rounded-2xl shadow-md p-8 mb-6">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="relative">
            <ImageWithFallback
              src={user.avatar}
              alt={user.name}
              className="w-32 h-32 rounded-full object-cover"
            />
            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center border-4 border-white">
              <CheckCircle className="text-white" size={24} />
            </div>
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-gray-900 mb-1">{user.name}</h1>
            <p className="text-teal-600 mb-3">{user.username}</p>
            <p className="text-sm text-gray-500 mb-4">Member since {user.joinedDate}</p>
            
            <div className="flex flex-wrap gap-6 justify-center md:justify-start">
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <Sparkles className="text-amber-500" size={20} />
                  <span className="text-2xl text-gray-900">{user.ecoPoints}</span>
                </div>
                <p className="text-sm text-gray-600">Eco Points</p>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <CheckCircle className="text-green-500" size={20} />
                  <span className="text-2xl text-gray-900">{user.verifiedPosts}</span>
                </div>
                <p className="text-sm text-gray-600">Verified Posts</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Eco Badges */}
      <div className="bg-white rounded-2xl shadow-md p-6 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Award className="text-teal-600" size={24} />
          <h2 className="text-teal-700">Eco Badges</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                badge.earned
                  ? 'border-teal-200 bg-teal-50'
                  : 'border-gray-200 bg-gray-50 opacity-50'
              }`}
            >
              <span className="text-4xl">{badge.icon}</span>
              <p className={`text-sm text-center ${
                badge.earned ? 'text-teal-700' : 'text-gray-500'
              }`}>
                {badge.name}
              </p>
              {badge.earned && (
                <CheckCircle className="text-teal-600" size={16} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Earned Rewards Summary */}
      <div className="bg-white rounded-2xl shadow-md p-6 mb-6">
        <h2 className="text-teal-700 mb-4">🎁 Earned Rewards</h2>
        <div className="space-y-3">
          {earnedRewards.map((reward) => (
            <div
              key={reward.id}
              className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-teal-50 rounded-xl border border-green-200"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{reward.icon}</span>
                <div>
                  <h3 className="text-gray-900 text-sm">{reward.title}</h3>
                  <p className="text-xs text-gray-500">Redeemed {reward.redeemedDate}</p>
                </div>
              </div>
              <CheckCircle className="text-green-600" size={20} />
            </div>
          ))}
        </div>
      </div>

      {/* Recent Posts */}
      <div className="bg-white rounded-2xl shadow-md p-6">
        <h2 className="text-teal-700 mb-4">📸 Recent Posts</h2>
        <div className="grid grid-cols-3 gap-3">
          {recentPosts.map((post) => (
            <div key={post.id} className="relative group cursor-pointer">
              <ImageWithFallback
                src={post.image}
                alt={post.location}
                className="w-full h-32 object-cover rounded-xl"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex flex-col items-center justify-center text-white">
                <MapPin size={20} className="mb-1" />
                <p className="text-xs text-center px-2">{post.location}</p>
                <p className="text-xs mt-1">❤️ {post.likes}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
